package dev.barterah;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class AhCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBS = List.of(
            "sell", "buy", "list", "my", "offers", "accept", "reject", "withdraw", "cancel", "claim", "help");
    private static final int PAGE_SIZE = 8;
    private static final Component PREFIX = Component.text("[AH] ", NamedTextColor.GOLD);

    private final JavaPlugin plugin;
    private final Store store;

    public AhCommand(JavaPlugin plugin, Store store) {
        this.plugin = plugin;
        this.store = store;
    }

    // ---------- util pesan ----------

    private void info(CommandSender s, String text) {
        s.sendMessage(PREFIX.append(Component.text(text, NamedTextColor.YELLOW)));
    }

    private void err(CommandSender s, String text) {
        s.sendMessage(PREFIX.append(Component.text(text, NamedTextColor.RED)));
    }

    private void notifyPlayer(UUID uuid, Component msg) {
        Player p = Bukkit.getPlayer(uuid);
        if (p != null) {
            p.sendMessage(PREFIX.append(msg));
        }
    }

    private static Component itemText(ItemStack item) {
        return Component.text(item.getAmount() + "x ", NamedTextColor.WHITE).append(item.displayName());
    }

    /** Simpan data, lalu kirim item klaim ke pemain yang online. */
    private void finish(List<UUID> uuids) {
        store.save();
        for (UUID u : uuids) {
            int left = store.flush(u);
            if (left > 0) {
                notifyPlayer(u, Component.text("Inventory penuh, " + left
                        + " item menunggu. Kosongkan lalu ketik /ah claim", NamedTextColor.YELLOW));
            }
        }
    }

    // ---------- dispatch ----------

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Command ini hanya untuk pemain.");
            return true;
        }
        String sub = args.length == 0 ? "help" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "sell" -> sell(p, args);
            case "buy", "offer" -> buy(p, args);
            case "list" -> list(p, args);
            case "my" -> my(p);
            case "offers" -> offers(p, args);
            case "accept" -> accept(p, args);
            case "reject" -> reject(p, args);
            case "withdraw" -> withdraw(p, args);
            case "cancel" -> cancel(p, args);
            case "claim" -> claim(p);
            case "reload" -> reload(p);
            default -> help(p);
        }
        return true;
    }

    private void help(Player p) {
        p.sendMessage(Component.text("=== Auction House Barter ===", NamedTextColor.GOLD));
        String[] lines = {
                "/ah sell [item yang diinginkan] - jual item di tangan (satu stack penuh)",
                "/ah list [halaman] - lihat semua listing",
                "/ah buy <id> - ajukan tawaran pakai item di tangan",
                "/ah my - lihat listing & tawaranmu",
                "/ah offers <id> - lihat tawaran masuk di listingmu",
                "/ah accept <id> <pemain> - terima tawaran",
                "/ah reject <id> <pemain> - tolak tawaran",
                "/ah withdraw <id> - tarik tawaranmu",
                "/ah cancel <id> - batalkan listingmu",
                "/ah claim - ambil item yang tertahan"
        };
        for (String l : lines) {
            p.sendMessage(Component.text(l, NamedTextColor.GRAY));
        }
    }

    // ---------- helper ----------

    private Store.Listing listing(Player p, String[] args) {
        if (args.length < 2) {
            err(p, "Sebutin ID listing-nya. Contoh: /ah " + args[0] + " 3");
            return null;
        }
        try {
            Store.Listing l = store.get(Integer.parseInt(args[1]));
            if (l == null) {
                err(p, "Listing #" + args[1] + " gak ketemu.");
            }
            return l;
        } catch (NumberFormatException e) {
            err(p, "ID harus angka.");
            return null;
        }
    }

    private static Store.Offer findOffer(Store.Listing l, String name) {
        for (Store.Offer o : l.offers.values()) {
            if (o.name.equalsIgnoreCase(name)) {
                return o;
            }
        }
        return null;
    }

    private Component line(Store.Listing l) {
        Component c = Component.text("#" + l.id + " ", NamedTextColor.GRAY)
                .append(Component.text(l.sellerName + ": ", NamedTextColor.AQUA))
                .append(itemText(l.item));
        if (!l.wants.isEmpty()) {
            c = c.append(Component.text(" | mau: " + l.wants, NamedTextColor.GREEN));
        }
        c = c.append(Component.text(" (" + l.offers.size() + " tawaran)", NamedTextColor.GRAY));
        return c.clickEvent(ClickEvent.suggestCommand("/ah buy " + l.id));
    }

    // ---------- subcommand ----------

    private void sell(Player p, String[] args) {
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) {
            err(p, "Pegang item yang mau dijual di tangan dulu.");
            return;
        }
        int max = plugin.getConfig().getInt("max-listings-per-player", 5);
        long mine = store.all().stream().filter(l -> l.seller.equals(p.getUniqueId())).count();
        if (mine >= max) {
            err(p, "Kamu sudah punya " + mine + " listing (maks " + max + "). Batalkan salah satu dulu.");
            return;
        }
        String wants = args.length > 1 ? String.join(" ", Arrays.copyOfRange(args, 1, args.length)) : "";
        if (wants.length() > 60) {
            wants = wants.substring(0, 60);
        }
        ItemStack item = hand.clone();
        p.getInventory().setItemInMainHand(null);
        Store.Listing l = store.createListing(p.getUniqueId(), p.getName(), item, wants);
        store.save();

        info(p, "Listing #" + l.id + " dibuat. Item disimpan sampai ada tawaran yang kamu terima.");
        if (plugin.getConfig().getBoolean("broadcast-new-listing", true)) {
            Bukkit.broadcast(PREFIX.append(Component.text(p.getName() + " menjual ", NamedTextColor.YELLOW))
                    .append(itemText(item))
                    .append(Component.text(". Tawar pakai /ah buy " + l.id, NamedTextColor.YELLOW)));
        }
    }

    private void buy(Player p, String[] args) {
        Store.Listing l = listing(p, args);
        if (l == null) {
            return;
        }
        if (l.seller.equals(p.getUniqueId())) {
            err(p, "Gak bisa nawar listing sendiri.");
            return;
        }
        if (l.offers.containsKey(p.getUniqueId())) {
            err(p, "Kamu sudah ajukan tawaran di listing ini. Tarik dulu pakai /ah withdraw " + l.id);
            return;
        }
        int maxOffers = plugin.getConfig().getInt("max-offers-per-listing", 10);
        if (l.offers.size() >= maxOffers) {
            err(p, "Listing ini sudah penuh tawaran.");
            return;
        }
        ItemStack hand = p.getInventory().getItemInMainHand();
        if (hand.getType().isAir()) {
            err(p, "Pegang item yang mau kamu tawarkan di tangan.");
            return;
        }
        ItemStack item = hand.clone();
        p.getInventory().setItemInMainHand(null);
        l.offers.put(p.getUniqueId(), new Store.Offer(p.getUniqueId(), p.getName(), item, System.currentTimeMillis()));
        store.save();

        p.sendMessage(PREFIX.append(Component.text("Tawaran dikirim ke " + l.sellerName + ": ", NamedTextColor.YELLOW))
                .append(itemText(item)));
        notifyPlayer(l.seller, Component.text(p.getName() + " menawar listing #" + l.id + " pakai ", NamedTextColor.YELLOW)
                .append(itemText(item))
                .append(Component.text(". Cek: /ah offers " + l.id, NamedTextColor.YELLOW)));
    }

    private void list(Player p, String[] args) {
        List<Store.Listing> all = new ArrayList<>(store.all());
        if (all.isEmpty()) {
            info(p, "AH masih kosong. Pasang item pakai /ah sell.");
            return;
        }
        int pages = (all.size() + PAGE_SIZE - 1) / PAGE_SIZE;
        int page = 1;
        if (args.length > 1) {
            try {
                page = Integer.parseInt(args[1]);
            } catch (NumberFormatException ignored) {
                // pakai halaman 1
            }
        }
        page = Math.max(1, Math.min(page, pages));
        p.sendMessage(Component.text("=== Auction House (" + page + "/" + pages + ") ===", NamedTextColor.GOLD));
        int from = (page - 1) * PAGE_SIZE;
        int to = Math.min(all.size(), page * PAGE_SIZE);
        for (int i = from; i < to; i++) {
            p.sendMessage(line(all.get(i)));
        }
        if (page < pages) {
            p.sendMessage(Component.text("Halaman berikutnya: /ah list " + (page + 1), NamedTextColor.GRAY));
        }
    }

    private void my(Player p) {
        boolean any = false;
        p.sendMessage(Component.text("=== Listing kamu ===", NamedTextColor.GOLD));
        for (Store.Listing l : store.all()) {
            if (l.seller.equals(p.getUniqueId())) {
                p.sendMessage(line(l));
                any = true;
            }
        }
        if (!any) {
            p.sendMessage(Component.text("(kosong)", NamedTextColor.GRAY));
        }
        p.sendMessage(Component.text("=== Tawaran yang kamu ajukan ===", NamedTextColor.GOLD));
        any = false;
        for (Store.Listing l : store.all()) {
            Store.Offer o = l.offers.get(p.getUniqueId());
            if (o != null) {
                p.sendMessage(Component.text("#" + l.id + " (" + l.sellerName + ") <- ", NamedTextColor.GRAY)
                        .append(itemText(o.item)));
                any = true;
            }
        }
        if (!any) {
            p.sendMessage(Component.text("(kosong)", NamedTextColor.GRAY));
        }
    }

    private void offers(Player p, String[] args) {
        Store.Listing l = listing(p, args);
        if (l == null) {
            return;
        }
        if (!l.seller.equals(p.getUniqueId()) && !p.hasPermission("barterah.admin")) {
            err(p, "Itu bukan listing kamu.");
            return;
        }
        p.sendMessage(Component.text("=== Tawaran untuk #" + l.id + " ===", NamedTextColor.GOLD));
        p.sendMessage(Component.text("Item kamu: ", NamedTextColor.GRAY).append(itemText(l.item)));
        if (l.offers.isEmpty()) {
            p.sendMessage(Component.text("Belum ada tawaran.", NamedTextColor.GRAY));
            return;
        }
        for (Store.Offer o : l.offers.values()) {
            p.sendMessage(Component.text(o.name + ": ", NamedTextColor.AQUA)
                    .append(itemText(o.item))
                    .append(Component.text("  [klik untuk terima]", NamedTextColor.GREEN)
                            .clickEvent(ClickEvent.suggestCommand("/ah accept " + l.id + " " + o.name)))
                    .append(Component.text(" [tolak]", NamedTextColor.RED)
                            .clickEvent(ClickEvent.suggestCommand("/ah reject " + l.id + " " + o.name))));
        }
    }

    private void accept(Player p, String[] args) {
        Store.Listing l = listing(p, args);
        if (l == null) {
            return;
        }
        if (!l.seller.equals(p.getUniqueId())) {
            err(p, "Itu bukan listing kamu.");
            return;
        }
        if (args.length < 3) {
            err(p, "Format: /ah accept <id> <nama pemain>");
            return;
        }
        Store.Offer o = findOffer(l, args[2]);
        if (o == null) {
            err(p, "Gak ada tawaran dari " + args[2] + " di listing ini.");
            return;
        }

        store.remove(l.id);
        store.give(l.seller, o.item);
        store.give(o.offerer, l.item);
        List<UUID> touched = new ArrayList<>(List.of(l.seller, o.offerer));
        for (Store.Offer other : l.offers.values()) {
            if (other == o) {
                continue;
            }
            store.give(other.offerer, other.item);
            touched.add(other.offerer);
            notifyPlayer(other.offerer, Component.text("Listing #" + l.id
                    + " sudah ditukar ke orang lain. Itemmu dikembalikan.", NamedTextColor.YELLOW));
        }

        p.sendMessage(PREFIX.append(Component.text("Tukar selesai! Kamu dapat ", NamedTextColor.GREEN))
                .append(itemText(o.item)));
        notifyPlayer(o.offerer, Component.text("Tawaranmu di listing #" + l.id + " DITERIMA! Kamu dapat ",
                NamedTextColor.GREEN).append(itemText(l.item)));
        finish(touched);
    }

    private void reject(Player p, String[] args) {
        Store.Listing l = listing(p, args);
        if (l == null) {
            return;
        }
        if (!l.seller.equals(p.getUniqueId())) {
            err(p, "Itu bukan listing kamu.");
            return;
        }
        if (args.length < 3) {
            err(p, "Format: /ah reject <id> <nama pemain>");
            return;
        }
        Store.Offer o = findOffer(l, args[2]);
        if (o == null) {
            err(p, "Gak ada tawaran dari " + args[2] + " di listing ini.");
            return;
        }
        l.offers.remove(o.offerer);
        store.give(o.offerer, o.item);
        info(p, "Tawaran dari " + o.name + " ditolak.");
        notifyPlayer(o.offerer, Component.text("Tawaranmu di listing #" + l.id
                + " ditolak. Itemmu dikembalikan.", NamedTextColor.YELLOW));
        finish(List.of(o.offerer));
    }

    private void withdraw(Player p, String[] args) {
        Store.Listing l = listing(p, args);
        if (l == null) {
            return;
        }
        Store.Offer o = l.offers.remove(p.getUniqueId());
        if (o == null) {
            err(p, "Kamu gak punya tawaran di listing ini.");
            return;
        }
        store.give(p.getUniqueId(), o.item);
        info(p, "Tawaran ditarik, itemmu dikembalikan.");
        finish(List.of(p.getUniqueId()));
    }

    private void cancel(Player p, String[] args) {
        Store.Listing l = listing(p, args);
        if (l == null) {
            return;
        }
        boolean admin = p.hasPermission("barterah.admin");
        if (!l.seller.equals(p.getUniqueId()) && !admin) {
            err(p, "Itu bukan listing kamu.");
            return;
        }
        store.remove(l.id);
        store.give(l.seller, l.item);
        List<UUID> touched = new ArrayList<>();
        touched.add(l.seller);
        for (Store.Offer o : l.offers.values()) {
            store.give(o.offerer, o.item);
            touched.add(o.offerer);
            notifyPlayer(o.offerer, Component.text("Listing #" + l.id
                    + " dibatalkan. Itemmu dikembalikan.", NamedTextColor.YELLOW));
        }
        info(p, "Listing #" + l.id + " dibatalkan, item dikembalikan ke " + l.sellerName + ".");
        finish(touched);
    }

    private void claim(Player p) {
        int left = store.flush(p.getUniqueId());
        if (left > 0) {
            err(p, "Masih ada " + left + " item yang belum muat. Kosongkan inventory lalu coba lagi.");
        } else {
            info(p, "Gak ada item yang tertahan, atau semuanya sudah masuk inventory.");
        }
    }

    private void reload(Player p) {
        if (!p.hasPermission("barterah.admin")) {
            err(p, "Kamu gak punya izin.");
            return;
        }
        plugin.reloadConfig();
        info(p, "Config di-reload.");
    }

    // ---------- tab complete ----------

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : SUBS) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) {
                    out.add(s);
                }
            }
            return out;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2 && List.of("buy", "offers", "accept", "reject", "withdraw", "cancel").contains(sub)) {
            for (Store.Listing l : store.all()) {
                String id = String.valueOf(l.id);
                if (id.startsWith(args[1])) {
                    out.add(id);
                }
            }
        } else if (args.length == 3 && (sub.equals("accept") || sub.equals("reject"))) {
            try {
                Store.Listing l = store.get(Integer.parseInt(args[1]));
                if (l != null) {
                    for (Store.Offer o : l.offers.values()) {
                        if (o.name.toLowerCase(Locale.ROOT).startsWith(args[2].toLowerCase(Locale.ROOT))) {
                            out.add(o.name);
                        }
                    }
                }
            } catch (NumberFormatException ignored) {
                // abaikan
            }
        }
        return out;
    }
}
